import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="degradedDoc_TUM", # Replace with your own username
    version="1.0.2",
    author="Florian Alkofer",
    author_email="flo.alkofer@tum.de",
    description="Package for OCR on degraded typewriter documents",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/someflow/degradedDoc",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)